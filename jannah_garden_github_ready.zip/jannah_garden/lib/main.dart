import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const JannahGardenApp());
}

class JannahGardenApp extends StatelessWidget {
  const JannahGardenApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'حديقة الجنة',
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: const Color(0xFF2C6E49),
        fontFamily: 'Roboto',
      ),
      home: const RootScreen(),
    );
  }
}

// ---------------------- Models ----------------------
class Dhikr {
  final String id;
  final String titleAr;
  final String? translit;
  final String? desc;
  final int rewardUnit; // عدد التسبيحات بكل ضغطة (عادة 1)

  const Dhikr({
    required this.id,
    required this.titleAr,
    this.translit,
    this.desc,
    this.rewardUnit = 1,
  });
}

// نوع العنصر المرئي في الحديقة
enum GardenItem { palm, palace, leaf }

class Rule {
  final String id;
  final String triggerDhikrId; // يشتغل عند هذا الذكر/السورة
  final GardenItem item;
  final int everyCount; // كل كم تكرار نمنح العنصر؟ 1 = كل مرة
  final int amount; // نضيف كم عنصر؟
  final bool isWeakOrDisputed; // هل الرواية مختلف في صحتها؟
  final String hadithRef; // مرجع مختصر

  const Rule({
    required this.id,
    required this.triggerDhikrId,
    required this.item,
    required this.everyCount,
    required this.amount,
    required this.hadithRef,
    this.isWeakOrDisputed = false,
  });
}

// ---------------------- Data ----------------------
const dhikrList = <Dhikr>[
  Dhikr(
    id: 'subhan_azim_bihamdih',
    titleAr: 'سُبْحَانَ اللّهِ العَظِيمِ وَبِحَمْدِهِ',
    desc: 'ورد: "مَن قال سبحان الله العظيم وبحمده غُرِست له نخلة في الجنة"',
  ),
  Dhikr(
    id: 'subhanallah',
    titleAr: 'سُبْحَانَ اللّهِ',
    desc: 'من الباقيات الصالحات',
  ),
  Dhikr(
    id: 'alhamdulillah',
    titleAr: 'الْحَمْدُ لِلّهِ',
    desc: 'من الباقيات الصالحات',
  ),
  Dhikr(
    id: 'allahu_akbar',
    titleAr: 'اللّهُ أَكْبَر',
    desc: 'من الباقيات الصالحات',
  ),
  Dhikr(
    id: 'la_ilaha_illallah',
    titleAr: 'لَا إِلَهَ إِلَّا اللّه',
    desc: 'من الباقيات الصالحات',
  ),
  Dhikr(
    id: 'la_hawla',
    titleAr: 'لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللّه',
    desc: 'من الباقيات الصالحات',
  ),
  Dhikr(
    id: 'ikhlas',
    titleAr: 'سورة الإخلاص',
    desc: 'تكرارها عشر مرات (خيار مختلف فيه) → قصر',
  ),
];

const defaultRules = <Rule>[
  Rule(
    id: 'r_palm_every_1',
    triggerDhikrId: 'subhan_azim_bihamdih',
    item: GardenItem.palm,
    everyCount: 1,
    amount: 1,
    hadithRef: 'سنن الترمذي/ابن ماجه (حسن): "…غُرِست له نخلة في الجنة"',
    isWeakOrDisputed: false,
  ),
  // الباقيات الصالحات → أوراق/بذور زخرفية
  Rule(
    id: 'r_leaf_subhan',
    triggerDhikrId: 'subhanallah',
    item: GardenItem.leaf,
    everyCount: 1,
    amount: 1,
    hadithRef: 'فضل الباقيات الصالحات',
  ),
  Rule(
    id: 'r_leaf_hamd',
    triggerDhikrId: 'alhamdulillah',
    item: GardenItem.leaf,
    everyCount: 1,
    amount: 1,
    hadithRef: 'فضل الباقيات الصالحات',
  ),
  Rule(
    id: 'r_leaf_akbar',
    triggerDhikrId: 'allahu_akbar',
    item: GardenItem.leaf,
    everyCount: 1,
    amount: 1,
    hadithRef: 'فضل الباقيات الصالحات',
  ),
  Rule(
    id: 'r_leaf_tahleel',
    triggerDhikrId: 'la_ilaha_illallah',
    item: GardenItem.leaf,
    everyCount: 1,
    amount: 1,
    hadithRef: 'فضل الباقيات الصالحات',
  ),
  Rule(
    id: 'r_leaf_hawla',
    triggerDhikrId: 'la_hawla',
    item: GardenItem.leaf,
    everyCount: 1,
    amount: 1,
    hadithRef: 'فضل الباقيات الصالحات',
  ),
  // الإخلاص 10 مرات → قصر (خيار مختلف فيه)
  Rule(
    id: 'r_palace_ikhlas10',
    triggerDhikrId: 'ikhlas',
    item: GardenItem.palace,
    everyCount: 10,
    amount: 1,
    hadithRef: 'روايات في قراءة الإخلاص 10 مرات → بيت/قصر (مختلف فيها)',
    isWeakOrDisputed: true,
  ),
];

// ---------------------- App State ----------------------
class AppState extends ChangeNotifier {
  // Counters for garden items
  int palms = 0; // 🌴
  int palaces = 0; // 🏰
  int leaves = 0; // 🍃

  // Per-dhikr recitation counters (to handle rules like every 10 times)
  final Map<String, int> dhikrCounts = { for (final d in dhikrList) d.id : 0 };

  bool includeWeak = false; // Settings

  // Simple animation flag
  String? lastBurstEmoji; // what to show in burst

  Future<void> load() async {
    final sp = await SharedPreferences.getInstance();
    palms = sp.getInt('palms') ?? 0;
    palaces = sp.getInt('palaces') ?? 0;
    leaves = sp.getInt('leaves') ?? 0;
    includeWeak = sp.getBool('includeWeak') ?? false;

    for (final d in dhikrList) {
      dhikrCounts[d.id] = sp.getInt('count_${d.id}') ?? 0;
    }
    notifyListeners();
  }

  Future<void> _persist() async {
    final sp = await SharedPreferences.getInstance();
    await sp.setInt('palms', palms);
    await sp.setInt('palaces', palaces);
    await sp.setInt('leaves', leaves);
    await sp.setBool('includeWeak', includeWeak);
    for (final e in dhikrCounts.entries) {
      await sp.setInt('count_${e.key}', e.value);
    }
  }

  void resetAll() {
    palms = 0; palaces = 0; leaves = 0;
    for (final k in dhikrCounts.keys) { dhikrCounts[k] = 0; }
    lastBurstEmoji = null;
    _persist();
    notifyListeners();
  }

  void toggleIncludeWeak(bool v) { includeWeak = v; _persist(); notifyListeners(); }

  // Core: increment a dhikr and apply rules
  void recite(String dhikrId, {int times = 1}) {
    dhikrCounts[dhikrId] = (dhikrCounts[dhikrId] ?? 0) + times;

    // Apply rules
    for (final r in defaultRules) {
      if (r.triggerDhikrId != dhikrId) continue;
      if (r.isWeakOrDisputed && !includeWeak) continue;

      final c = dhikrCounts[dhikrId]!;
      // grant reward for each time we cross a multiple of everyCount in this call
      for (int i = 0; i < times; i++) {
        final current = c - i;
        if (current % r.everyCount == 0) {
          _grant(r.item, r.amount);
        }
      }
    }

    _persist();
    notifyListeners();
  }

  void _grant(GardenItem item, int amount) {
    switch (item) {
      case GardenItem.palm:
        palms += amount; lastBurstEmoji = '🌴'; break;
      case GardenItem.palace:
        palaces += amount; lastBurstEmoji = '🏰'; break;
      case GardenItem.leaf:
        leaves += amount; lastBurstEmoji = '🍃'; break;
    }
  }
}

// ---------------------- Root & Tabs ----------------------
class RootScreen extends StatefulWidget {
  const RootScreen({super.key});

  @override
  State<RootScreen> createState() => _RootScreenState();
}

class _RootScreenState extends State<RootScreen> {
  final app = AppState();
  int tab = 0;

  @override
  void initState() {
    super.initState();
    app.load();
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      TasbeehScreen(app: app),
      GardenScreen(app: app),
      LibraryScreen(app: app),
    ];

    return AnimatedBuilder(
      animation: app,
      builder: (context, _) {
        return Scaffold(
          appBar: AppBar(
            title: const Text('حديقة الجنة'),
            actions: [
              IconButton(
                tooltip: 'إعدادات',
                onPressed: () async {
                  await showModalBottomSheet(
                    context: context,
                    showDragHandle: true,
                    builder: (_) => SettingsSheet(app: app),
                  );
                },
                icon: const Icon(Icons.settings_outlined),
              )
            ],
          ),
          body: pages[tab],
          bottomNavigationBar: NavigationBar(
            selectedIndex: tab,
            onDestinationSelected: (i) => setState(() => tab = i),
            destinations: const [
              NavigationDestination(icon: Icon(Icons.touch_app_outlined), label: 'التسبيح'),
              NavigationDestination(icon: Icon(Icons.park_outlined), label: 'الحديقة'),
              NavigationDestination(icon: Icon(Icons.menu_book_outlined), label: 'المكتبة'),
            ],
          ),
        );
      },
    );
  }
}

// ---------------------- Tasbeeh Screen ----------------------
class TasbeehScreen extends StatefulWidget {
  final AppState app;
  const TasbeehScreen({super.key, required this.app});

  @override
  State<TasbeehScreen> createState() => _TasbeehScreenState();
}

class _TasbeehScreenState extends State<TasbeehScreen> with SingleTickerProviderStateMixin {
  String currentId = dhikrList.first.id;
  double burstScale = 0.0;
  double burstOpacity = 0.0;

  void _animateBurst() {
    setState(() { burstScale = 1.8; burstOpacity = 1; });
    Future.delayed(const Duration(milliseconds: 280), () {
      if (!mounted) return;
      setState(() { burstScale = 0.0; burstOpacity = 0.0; });
    });
  }

  @override
  Widget build(BuildContext context) {
    final app = widget.app;
    final current = dhikrList.firstWhere((d) => d.id == currentId);
    final count = app.dhikrCounts[currentId] ?? 0;

    return Stack(
      children: [
        ListView(
          padding: const EdgeInsets.all(16),
          children: [
            DropdownButtonFormField<String>(
              value: currentId,
              items: [
                for (final d in dhikrList)
                  DropdownMenuItem(value: d.id, child: Text(d.titleAr)),
              ],
              onChanged: (v) => setState(() => currentId = v!),
              decoration: const InputDecoration(
                labelText: 'اختر الذكر/السورة',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 16),
            Card(
              elevation: 0,
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Text(current.titleAr, textAlign: TextAlign.center, style: Theme.of(context).textTheme.titleLarge),
                    if (current.desc != null) ...[
                      const SizedBox(height: 8),
                      Text(current.desc!, textAlign: TextAlign.center, style: Theme.of(context).textTheme.bodyMedium),
                    ],
                    const SizedBox(height: 24),
                    Text('العدد الحالي: $count', textAlign: TextAlign.center, style: Theme.of(context).textTheme.titleMedium),
                    const SizedBox(height: 16),
                    SizedBox(
                      height: 220,
                      child: Center(
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            shape: const CircleBorder(),
                            padding: const EdgeInsets.all(36),
                          ),
                          onPressed: () {
                            app.recite(currentId);
                            _animateBurst();
                          },
                          child: const Text('سَبِّح')
                        ),
                      ),
                    ),
                    const SizedBox(height: 12),
                    FilledButton.tonal(
                      onPressed: () { app.recite(currentId, times: 10); _animateBurst(); },
                      child: const Text('×10'),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
        // Burst Emoji animation overlay
        Positioned.fill(
          child: IgnorePointer(
            ignoring: true,
            child: Center(
              child: AnimatedOpacity(
                duration: const Duration(milliseconds: 280),
                opacity: burstOpacity,
                child: AnimatedScale(
                  duration: const Duration(milliseconds: 280),
                  scale: burstScale,
                  child: Text(widget.app.lastBurstEmoji ?? '✨', style: const TextStyle(fontSize: 64)),
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }
}

// ---------------------- Garden Screen ----------------------
class GardenScreen extends StatelessWidget {
  final AppState app;
  const GardenScreen({super.key, required this.app});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: app,
      builder: (context, _) {
        final stats = [
          _Stat('النخيل', '🌴', app.palms),
          _Stat('القصور', '🏰', app.palaces),
          _Stat('الأوراق', '🍃', app.leaves),
        ];

        return ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Wrap(
              spacing: 12, runSpacing: 12,
              children: [
                for (final s in stats)
                  _StatCard(stat: s),
              ],
            ),
            const SizedBox(height: 16),
            Card(
              elevation: 0,
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('مشهد الحديقة', style: Theme.of(context).textTheme.titleLarge),
                    const SizedBox(height: 12),
                    // مشهد بسيط شبكي يتكاثر فيه الإيموجيز
                    SizedBox(
                      height: 220,
                      child: GridView.count(
                        crossAxisCount: 8,
                        mainAxisSpacing: 4,
                        crossAxisSpacing: 4,
                        children: [
                          for (int i = 0; i < app.palms; i++) const Center(child: Text('🌴')),
                          for (int i = 0; i < app.palaces; i++) const Center(child: Text('🏰')),
                          for (int i = 0; i < app.leaves; i++) const Center(child: Text('🍃')),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        );
      },
    );
  }
}

class _Stat {
  final String label; final String emoji; final int value;
  _Stat(this.label, this.emoji, this.value);
}

class _StatCard extends StatelessWidget {
  final _Stat stat;
  const _StatCard({required this.stat});
  @override
  Widget build(BuildContext context) {
    return AnimatedScale(
      duration: const Duration(milliseconds: 250),
      scale: 1 + (stat.value > 0 ? 0.02 : 0),
      child: Container(
        width: 180,
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.surface,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: Theme.of(context).dividerColor),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(stat.emoji, style: const TextStyle(fontSize: 28)),
            const SizedBox(height: 8),
            Text(stat.label, style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 6),
            Text('${stat.value}', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold)),
          ],
        ),
      ),
    );
  }
}

// ---------------------- Library / Rules ----------------------
class LibraryScreen extends StatelessWidget {
  final AppState app;
  const LibraryScreen({super.key, required this.app});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Text('الأذكار والسور', style: Theme.of(context).textTheme.titleLarge),
        const SizedBox(height: 8),
        for (final d in dhikrList)
          Card(
            elevation: 0,
            child: ListTile(
              title: Text(d.titleAr),
              subtitle: d.desc != null ? Text(d.desc!) : null,
              trailing: Text('المجموع: ${app.dhikrCounts[d.id] ?? 0}'),
            ),
          ),
        const SizedBox(height: 16),
        Text('قواعد المكافآت (Rewards)', style: Theme.of(context).textTheme.titleLarge),
        const SizedBox(height: 8),
        for (final r in defaultRules)
          Card(
            elevation: 0,
            child: ListTile(
              title: Text(_ruleTitle(r)),
              subtitle: Text(r.hadithRef + (r.isWeakOrDisputed ? ' — (مختلف فيها)' : '')),
            ),
          ),
      ],
    );
  }

  String _ruleTitle(Rule r) {
    final d = dhikrList.firstWhere((e) => e.id == r.triggerDhikrId);
    final item = switch (r.item) { GardenItem.palm => '🌴 نخلة', GardenItem.palace => '🏰 قصر', GardenItem.leaf => '🍃 ورقة' };
    return 'عند "${d.titleAr}" كل ${r.everyCount} × → ${r.amount} ${item}';
  }
}

// ---------------------- Settings Sheet ----------------------
class SettingsSheet extends StatelessWidget {
  final AppState app;
  const SettingsSheet({super.key, required this.app});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.settings_suggest_outlined),
              const SizedBox(width: 8),
              Text('إعدادات', style: Theme.of(context).textTheme.titleLarge),
            ],
          ),
          const SizedBox(height: 16),
          SwitchListTile(
            value: app.includeWeak,
            onChanged: (v) => app.toggleIncludeWeak(v),
            title: const Text('تفعيل القواعد المبنية على روايات مختلف في صحتها'),
            subtitle: const Text('مثل: "قراءة الإخلاص 10 مرات → قصر"'),
          ),
          const SizedBox(height: 8),
          FilledButton.tonal(
            onPressed: () async {
              final ok = await showDialog<bool>(
                context: context,
                builder: (_) => AlertDialog(
                  title: const Text('إعادة تعيين'),
                  content: const Text('هل تريد مسح كل العدادات والحديقة؟'),
                  actions: [
                    TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('لا')),
                    FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('نعم')),
                  ],
                ),
              );
              if (ok == true) {
                app.resetAll();
                if (context.mounted) Navigator.pop(context);
              }
            },
            child: const Text('إعادة ضبط الكل'),
          ),
          const SizedBox(height: 12),
        ],
      ),
    );
  }
}
