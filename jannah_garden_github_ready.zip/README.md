# Jannah Garden (Tasbeeh) — Flutter

هذا مستودع جاهز للرفع إلى GitHub من الهاتف. يحتوي على:
- مشروع Flutter كامل داخل مجلد `jannah_garden/`
- ملف GitHub Actions داخل `.github/workflows/flutter-android.yml` لبناء APK تلقائيًا

## كيف تستخدمه من الهاتف؟
1) ارفع هذا الملف المضغوط كاملاً إلى مستودع GitHub جديد (Public) باسم `jannah_garden`.
2) بعد الرفع، افتح تبويب **Actions** في المستودع.
3) شغّل الـWorkflow (Run workflow) أو انتظر تشغيله تلقائيًا.
4) بعد نجاح البناء ✅ حمّل ملف الـAPK من قسم **Artifacts** باسم `app-release`.

> لو حبيت نسخة Debug بدل Release: عدّل سطر البناء في yml إلى:
> `flutter build apk --debug`

